package com.nova.assistant

import android.accessibilityservice.AccessibilityButtonController
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * The "screen control" part of Nova. Android lets an Accessibility Service read what's on
 * screen, take screenshots, tap/swipe/type, and draw a floating panel over other apps.
 */
class AgentService : AccessibilityService() {

    private val main = Handler(Looper.getMainLooper())
    private val screenshotExecutor = Executors.newSingleThreadExecutor()
    private var panel: OverlayPanel? = null
    private var buttonCallback: AccessibilityButtonController.AccessibilityButtonCallback? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        // Optional extra trigger: the on-screen accessibility button / shortcut.
        try {
            val cb = object : AccessibilityButtonController.AccessibilityButtonCallback() {
                override fun onClicked(controller: AccessibilityButtonController) { togglePanel() }
            }
            accessibilityButtonController.registerAccessibilityButtonCallback(cb, main)
            buttonCallback = cb
        } catch (_: Exception) {}
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* not needed */ }

    override fun onInterrupt() { panel?.agent?.stop() }

    override fun onDestroy() {
        try { buttonCallback?.let { accessibilityButtonController.unregisterAccessibilityButtonCallback(it) } } catch (_: Exception) {}
        panel?.destroy()
        panel = null
        if (instance === this) instance = null
        screenshotExecutor.shutdownNow()
        super.onDestroy()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    // ---------------------------------------------------------------- panel

    fun showPanel() = main.post {
        val p = panel ?: OverlayPanel(this).also { panel = it }
        p.show()
    }

    fun togglePanel() = main.post {
        val p = panel
        if (p != null && p.isShowing) p.hide() else showPanel()
    }

    /** Runs [block] on the UI thread and waits for it (call from background threads only). */
    fun <T> onMainSync(block: () -> T): T? {
        if (Looper.myLooper() == Looper.getMainLooper()) return block()
        var result: T? = null
        val latch = CountDownLatch(1)
        main.post {
            try { result = block() } finally { latch.countDown() }
        }
        latch.await(3, TimeUnit.SECONDS)
        return result
    }

    // ---------------------------------------------------------------- seeing

    fun screenSize(): Rect {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 30) return Rect(wm.currentWindowMetrics.bounds)
        val dm = android.util.DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        return Rect(0, 0, dm.widthPixels, dm.heightPixels)
    }

    /** Blocking screenshot (background thread). Returns null if the system refuses. */
    fun takeScreenshotBlocking(): Bitmap? {
        if (Build.VERSION.SDK_INT < 30) return null // screenshots need Android 11+
        repeat(2) { attempt ->
            val latch = CountDownLatch(1)
            var bmp: Bitmap? = null
            try {
                takeScreenshot(Display.DEFAULT_DISPLAY, screenshotExecutor,
                    object : TakeScreenshotCallback {
                        override fun onSuccess(result: ScreenshotResult) {
                            try {
                                val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                                bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                                hw?.recycle()
                            } catch (_: Exception) {
                            } finally {
                                result.hardwareBuffer.close()
                                latch.countDown()
                            }
                        }

                        override fun onFailure(errorCode: Int) { latch.countDown() }
                    })
            } catch (_: Exception) {
                latch.countDown()
            }
            latch.await(5, TimeUnit.SECONDS)
            if (bmp != null) return bmp
            if (attempt == 0) Thread.sleep(450) // screenshots are rate-limited (~3/sec)
        }
        return null
    }

    // ---------------------------------------------------------------- doing

    private fun gesture(path: Path, durationMs: Long): Boolean {
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs.coerceAtLeast(1))
        val g = GestureDescription.Builder().addStroke(stroke).build()
        val latch = CountDownLatch(1)
        var ok = false
        val dispatched = onMainSync {
            dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) { ok = true; latch.countDown() }
                override fun onCancelled(gestureDescription: GestureDescription?) { latch.countDown() }
            }, main)
        } ?: false
        if (!dispatched) return false
        latch.await(durationMs + 3000, TimeUnit.MILLISECONDS)
        return ok
    }

    fun tap(x: Float, y: Float): Boolean =
        gesture(Path().apply { moveTo(x, y); lineTo(x + 1, y + 1) }, 60)

    fun longPress(x: Float, y: Float): Boolean =
        gesture(Path().apply { moveTo(x, y); lineTo(x + 1, y + 1) }, 900)

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 400): Boolean =
        gesture(Path().apply { moveTo(x1, y1); lineTo(x2, y2) }, durationMs)

    fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        var hops = 0
        while (n != null && hops < 6) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            n = n.parent
            hops++
        }
        val r = Rect().also { node.getBoundsInScreen(it) }
        return tap(r.exactCenterX(), r.exactCenterY())
    }

    fun longClickNode(node: AccessibilityNodeInfo): Boolean {
        if (node.isLongClickable && node.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)) return true
        val r = Rect().also { node.getBoundsInScreen(it) }
        return longPress(r.exactCenterX(), r.exactCenterY())
    }

    private fun focusedInput(): AccessibilityNodeInfo? =
        try { rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) } catch (_: Exception) { null }

    fun setText(node: AccessibilityNodeInfo?, text: String): Boolean {
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        if (node != null) {
            if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return true
            clickNode(node)
            Thread.sleep(400)
        }
        val f = focusedInput() ?: return false
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    /** Puts text on the clipboard and pastes it — better for long text and code. */
    fun paste(node: AccessibilityNodeInfo?, text: String): Boolean {
        onMainSync {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Nova", text))
        }
        Thread.sleep(150)
        val target = node ?: focusedInput()
        if (target != null) {
            target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            if (target.performAction(AccessibilityNodeInfo.ACTION_PASTE)) return true
            clickNode(target)
            Thread.sleep(350)
        }
        val f = focusedInput() ?: return false
        return f.performAction(AccessibilityNodeInfo.ACTION_PASTE)
    }

    fun copyToClipboard(text: String) {
        onMainSync {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Nova", text))
        }
    }

    fun pressEnter(node: AccessibilityNodeInfo?): Boolean {
        val target = node ?: focusedInput() ?: return false
        if (Build.VERSION.SDK_INT < 30) return false
        return target.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    fun scroll(direction: String, node: AccessibilityNodeInfo?): Boolean {
        if (node != null) {
            var n: AccessibilityNodeInfo? = node
            var hops = 0
            while (n != null && hops < 6) {
                if (n.isScrollable) {
                    val action = when (direction) {
                        "up", "left" -> AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                        else -> AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                    }
                    if (n.performAction(action)) return true
                    break
                }
                n = n.parent
                hops++
            }
        }
        val s = screenSize()
        val w = s.width().toFloat()
        val h = s.height().toFloat()
        return when (direction) {
            "up" -> swipe(w / 2, h * 0.30f, w / 2, h * 0.72f)
            "left" -> swipe(w * 0.20f, h / 2, w * 0.80f, h / 2)
            "right" -> swipe(w * 0.80f, h / 2, w * 0.20f, h / 2)
            else -> swipe(w / 2, h * 0.72f, w / 2, h * 0.30f) // "down": see content further down
        }
    }

    fun global(action: Int): Boolean = performGlobalAction(action)

    fun openApp(name: String): String {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        val q = name.trim().lowercase()
        val labeled = apps.map { it to (it.loadLabel(pm)?.toString() ?: "") }
        val match = labeled.firstOrNull { it.second.equals(q, ignoreCase = true) }
            ?: labeled.firstOrNull { it.second.lowercase().startsWith(q) }
            ?: labeled.firstOrNull { it.second.lowercase().contains(q) }
            ?: labeled.firstOrNull { it.first.activityInfo.packageName.lowercase().contains(q.replace(" ", "")) }
            ?: return "No installed app matches \"$name\". Installed apps include: " +
                labeled.map { it.second }.sorted().take(60).joinToString(", ")
        val intent = pm.getLaunchIntentForPackage(match.first.activityInfo.packageName)
            ?: return "Could not open ${match.second}."
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return try {
            startActivity(intent)
            "Opened ${match.second}."
        } catch (e: Exception) {
            "Failed to open ${match.second}: ${e.message}"
        }
    }

    fun openUrl(url: String): String {
        val fixed = if (url.contains("://")) url else "https://$url"
        return try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(fixed)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "Opened $fixed"
        } catch (e: Exception) {
            "Could not open $fixed: ${e.message}"
        }
    }

    companion object {
        @Volatile var instance: AgentService? = null
            private set

        val isRunning: Boolean get() = instance != null
    }
}
