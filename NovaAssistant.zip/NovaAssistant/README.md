# Nova — AI assistant that sees and controls your Android phone

Hold the side button → Nova pops up over whatever app you're in. Type or talk to it.
It can chat, answer questions, write/improve text, write code — and do tasks on the phone
(open apps, search, tap, scroll, type, paste code into websites) while you watch.
All AI runs through **OpenRouter** with the model you choose.

## Get the APK (no computer needed)

1. Create a free account at github.com and make a **new repository** (e.g. `nova`).
2. Upload everything in this folder to it (keep the folder structure, including `.github`).
3. Open the repo's **Actions** tab → "Build Nova APK" runs automatically (~5 min).
   If it doesn't start, open it and tap **Run workflow**.
4. Open the repo's **Releases** → newest build → download **Nova.apk** on your phone and install
   (allow "Install unknown apps" for your browser when asked).

Every time you change the code and push, a new APK is built that installs over the old one.

Prefer a computer? Open this folder in Android Studio and press Run.

## Set it up on the phone

1. **Open Nova** → paste your OpenRouter API key and a model ID → Save → Test.
   Use a model with image (vision) support so it can see the screen.
2. **Screen control**: Settings → Accessibility → Installed apps → *Nova screen control* → On.
   If the switch is greyed out: Settings → Apps → Nova → ⋮ → *Allow restricted settings*, then retry.
3. **Microphone**: tap "Allow microphone" in Nova.
4. **Side button**:
   - Settings → Apps → Choose default apps → Digital assistant app → Device assistance app → **Nova**
   - Settings → Advanced features → Side button → Press and hold → **Digital assistant wake-up**

Hold the side button anywhere. Backup way to open it: the accessibility shortcut button.

## How it works

| File | What it does |
|---|---|
| `MainActivity.kt` | Setup screen (API key, model ID, permissions) |
| `AssistActivity.kt` | Launched by the side button; shows the panel |
| `AgentService.kt` | Accessibility service: screenshots, tap/swipe/type, open apps/links |
| `OverlayPanel.kt` | Floating chat UI, mic (speech-to-text), spoken replies |
| `Agent.kt` | The loop: look → ask the model → do one action → repeat |
| `ScreenReader.kt` | Turns the screen into a numbered list of elements |
| `OpenRouterClient.kt` | Calls `openrouter.ai/api/v1/chat/completions` |

Each step sends a screenshot + element list to the model, which replies with one JSON action
(`tap`, `type`, `paste`, `scroll`, `open_app`, `open_url`, `reply`, `ask`, …).
Nova asks before sending messages, posting, paying or deleting.

## Good to know

- Every step is an API call with an image, so long tasks use more credits. Tap **Stop** anytime.
- Banking apps and password screens block screenshots — Nova can't see those.
- Your API key is stored only on your phone.
- Requires Android 11 or newer.
