package com.nova.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.role.RoleManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray

/** Setup screen: paste your OpenRouter key + model ID, then turn on the permissions. */
@SuppressLint("SetTextI18n")
class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var keyField: EditText
    private lateinit var modelField: EditText
    private lateinit var a11yStatus: TextView
    private lateinit var micStatus: TextView
    private lateinit var assistStatus: TextView
    private lateinit var keyStatus: TextView

    private val bg = Color.parseColor("#0F0F14")
    private val card = Color.parseColor("#1A1A22")
    private val accent = Color.parseColor("#7C5CFF")
    private val textMain = Color.parseColor("#F2F2F7")
    private val textDim = Color.parseColor("#9A9AAE")
    private val good = Color.parseColor("#3DDC97")
    private val bad = Color.parseColor("#FF7A85")

    private fun dp(v: Int) =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val scroll = ScrollView(this).apply { setBackgroundColor(bg); isFillViewport = true }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(40))
        }
        scroll.addView(col)
        setContentView(scroll)

        col.addView(TextView(this).apply {
            text = "✦ Nova"; textSize = 30f; setTextColor(textMain); typeface = Typeface.DEFAULT_BOLD
        })
        col.addView(text("Your AI assistant that can see and use your phone. Powered by any model on OpenRouter.", dim = true)
            .apply { setPadding(0, dp(4), 0, dp(18)) })

        // ---------------- API settings
        val api = section(col, "1. Connect OpenRouter")
        api.addView(label("API key"))
        keyField = field("sk-or-…", password = true).apply { setText(prefs.apiKey) }
        api.addView(keyField)
        api.addView(label("Model ID"))
        modelField = field("e.g. openai/gpt-4o", password = false).apply {
            setText(prefs.model)
            imeOptions = EditorInfo.IME_ACTION_DONE
            setOnEditorActionListener { _, actionId, event ->
                val enter = actionId == EditorInfo.IME_ACTION_DONE ||
                    (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
                if (enter) { save(); true } else false
            }
        }
        api.addView(modelField)
        api.addView(text("Pick a model that supports images (vision) so Nova can see the screen.", dim = true, size = 12f))
        val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btnRow.addView(button("Save", primary = true) { save() }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
        btnRow.addView(button("Test", primary = false) { test() }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(6) })
        api.addView(btnRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        keyStatus = text("", dim = true, size = 13f).apply { setPadding(0, dp(8), 0, 0) }
        api.addView(keyStatus)
        api.addView(link("Get an API key / browse models →") { openUrl("https://openrouter.ai/models") })

        // ---------------- options
        val opt = section(col, "Options")
        opt.addView(switch("See the screen (send screenshots)", prefs.useVision) { prefs.useVision = it })
        opt.addView(switch("Read replies out loud when I use voice", prefs.speakReplies) { prefs.speakReplies = it })

        // ---------------- permissions
        val s2 = section(col, "2. Allow screen control")
        s2.addView(text("Lets Nova see the screen, tap, swipe and type. Settings → Accessibility → Installed apps → Nova → On.", dim = true))
        a11yStatus = status()
        s2.addView(a11yStatus)
        s2.addView(button("Open Accessibility settings", primary = true) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        s2.addView(text("Switch greyed out (\"Restricted setting\")? Tap below → ⋮ menu (top right) → \"Allow restricted settings\", then try again.", dim = true, size = 12f)
            .apply { setPadding(0, dp(10), 0, 0) })
        s2.addView(link("Open Nova's App info →") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })

        val s3 = section(col, "3. Allow microphone (to talk to it)")
        micStatus = status()
        s3.addView(micStatus)
        s3.addView(button("Allow microphone", primary = false) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
        })

        val s4 = section(col, "4. Open it with the side button")
        s4.addView(text("a) Make Nova your Default digital assistant app:\nSettings → Apps → Choose default apps → Digital assistant app → Device assistance app → Nova.", dim = true))
        assistStatus = status()
        s4.addView(assistStatus)
        s4.addView(button("Open default apps", primary = true) { openDefaultApps() })
        s4.addView(text("b) Samsung: Settings → Advanced features → Side button → Press and hold → Digital assistant wake-up.\n\nNow hold the side button anywhere and Nova pops up.", dim = true)
            .apply { setPadding(0, dp(12), 0, 0) })

        val s5 = section(col, "Try it")
        s5.addView(button("Open Nova now", primary = true) {
            val svc = AgentService.instance
            if (svc == null) toast("Turn on screen control (step 2) first.")
            else { svc.showPanel(); moveTaskToBack(true) }
        })
        s5.addView(text("Tip: Nova costs OpenRouter credits for each step it takes. Tap Stop anytime.", dim = true, size = 12f)
            .apply { setPadding(0, dp(10), 0, 0) })
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshStatus()
    }

    private fun refreshStatus() {
        setStatus(a11yStatus, AgentService.isRunning || isAccessibilityEnabled(), "Screen control is on", "Screen control is off")
        setStatus(micStatus, checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED,
            "Microphone allowed", "Microphone not allowed")
        val rm = getSystemService(RoleManager::class.java)
        val held = try { rm?.isRoleHeld(RoleManager.ROLE_ASSISTANT) == true } catch (_: Exception) { false }
        setStatus(assistStatus, held, "Nova is your digital assistant", "Nova is not the digital assistant yet")
        setStatus(keyStatus, prefs.isConfigured, "Saved: ${prefs.model}", "Enter your API key and model ID, then Save")
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val me = ComponentName(this, AgentService::class.java)
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == me }
    }

    private fun save() {
        val key = keyField.text.toString().trim()
        val model = modelField.text.toString().trim()
        if (key.isEmpty() || model.isEmpty()) { toast("Enter both the API key and the model ID"); return }
        prefs.apiKey = key
        prefs.model = model
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(modelField.windowToken, 0)
        toast("Saved ✓")
        refreshStatus()
    }

    private fun test() {
        save()
        if (!prefs.isConfigured) return
        keyStatus.text = "Testing…"; keyStatus.setTextColor(textDim)
        val client = OpenRouterClient(prefs.apiKey, prefs.model)
        Thread {
            val result = try {
                val msgs = JSONArray().put(OpenRouterClient.msg("user", "Reply with just: OK"))
                val r = client.chat(msgs, maxTokens = 20)
                true to "Works! Model replied: ${r.trim().take(60)}"
            } catch (e: Exception) {
                false to (e.message ?: "Failed")
            }
            runOnUiThread {
                keyStatus.text = (if (result.first) "✓ " else "✗ ") + result.second
                keyStatus.setTextColor(if (result.first) good else bad)
            }
        }.start()
    }

    private fun openDefaultApps() {
        val intents = listOf(
            Intent(Settings.ACTION_VOICE_INPUT_SETTINGS),
            Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS),
            Intent(Settings.ACTION_SETTINGS),
        )
        for (i in intents) {
            try { startActivity(i); return } catch (_: Exception) {}
        }
    }

    private fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {}
    }

    // ---------------- tiny UI helpers

    private fun section(parent: LinearLayout, title: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(card, 20)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        box.addView(TextView(this).apply {
            text = title; textSize = 17f; setTextColor(textMain); typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(8))
        })
        parent.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        return box
    }

    private fun text(s: String, dim: Boolean = false, size: Float = 14f) = TextView(this).apply {
        text = s; textSize = size; setTextColor(if (dim) textDim else textMain); setLineSpacing(0f, 1.15f)
    }

    private fun label(s: String) = text(s, dim = true, size = 13f).apply { setPadding(0, dp(8), 0, dp(4)) }

    private fun field(hint: String, password: Boolean) = EditText(this).apply {
        this.hint = hint
        setHintTextColor(Color.parseColor("#5C5C6E")); setTextColor(textMain); textSize = 15f
        background = rounded(Color.parseColor("#24242E"), 12)
        setPadding(dp(12), dp(12), dp(12), dp(12))
        isSingleLine = true
        inputType = if (password) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
    }

    private fun button(s: String, primary: Boolean, onClick: () -> Unit) = TextView(this).apply {
        text = s; textSize = 15f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        background = rounded(if (primary) accent else Color.parseColor("#2C2C38"), 14)
        setPadding(dp(14), dp(13), dp(14), dp(13))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
        setOnClickListener { onClick() }
    }

    private fun link(s: String, onClick: () -> Unit) = TextView(this).apply {
        text = s; textSize = 14f; setTextColor(accent)
        setPadding(0, dp(10), 0, dp(2))
        setOnClickListener { onClick() }
    }

    private fun status() = text("", size = 13f).apply { setPadding(0, dp(8), 0, 0) }

    private fun setStatus(v: TextView, ok: Boolean, yes: String, no: String) {
        v.text = if (ok) "✓ $yes" else "✗ $no"
        v.setTextColor(if (ok) good else bad)
    }

    private fun switch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) = Switch(this).apply {
        text = label; textSize = 14f; setTextColor(textMain); isChecked = checked
        setPadding(0, dp(6), 0, dp(6))
        setOnCheckedChangeListener { _, c -> onChange(c) }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

}
