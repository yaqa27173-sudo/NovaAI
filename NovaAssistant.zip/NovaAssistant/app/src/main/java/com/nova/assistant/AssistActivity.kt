package com.nova.assistant

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

/**
 * Launched by Android when you hold the side/power key (or swipe from the corner) and Nova is
 * your Default digital assistant. It just pops up the floating panel and disappears,
 * so the app you were using stays on screen.
 */
class AssistActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val svc = AgentService.instance
        if (svc != null) {
            svc.showPanel()
        } else {
            Toast.makeText(this, "Turn on Nova screen control first", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        finish()
        overridePendingTransition(0, 0)
    }
}
