package com.nova.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/** Minimal OpenRouter chat-completions client. Call from a background thread. */
class OpenRouterClient(private val apiKey: String, private val model: String) {

    class ApiException(message: String) : Exception(message)

    @Volatile private var activeConnection: HttpURLConnection? = null

    fun cancel() {
        try { activeConnection?.disconnect() } catch (_: Exception) {}
    }

    fun chat(messages: JSONArray, maxTokens: Int = 2500, temperature: Double = 0.2): String {
        val body = JSONObject()
            .put("model", model)
            .put("messages", messages)
            .put("max_tokens", maxTokens)
            .put("temperature", temperature)

        val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 30_000
            readTimeout = 120_000
            doOutput = true
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("HTTP-Referer", "https://github.com/nova-assistant")
            setRequestProperty("X-Title", "Nova Assistant")
        }
        activeConnection = conn
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.let { s ->
                BufferedReader(InputStreamReader(s, Charsets.UTF_8)).use { it.readText() }
            } ?: ""
            if (code !in 200..299) throw ApiException(friendlyError(code, text))

            val json = JSONObject(text)
            json.optJSONObject("error")?.let { throw ApiException(it.optString("message", "Unknown error")) }
            val choices = json.optJSONArray("choices")
            if (choices == null || choices.length() == 0) throw ApiException("The model returned no answer.")
            val message = choices.getJSONObject(0).optJSONObject("message")
                ?: throw ApiException("The model returned no message.")
            return contentToString(message.opt("content"))
        } finally {
            conn.disconnect()
            activeConnection = null
        }
    }

    private fun contentToString(content: Any?): String = when (content) {
        is String -> content
        is JSONArray -> buildString {
            for (i in 0 until content.length()) {
                val part = content.optJSONObject(i) ?: continue
                append(part.optString("text", ""))
            }
        }
        else -> ""
    }

    private fun friendlyError(code: Int, body: String): String {
        val msg = try {
            JSONObject(body).optJSONObject("error")?.optString("message")
        } catch (_: Exception) { null } ?: body.take(300)
        return when (code) {
            401 -> "OpenRouter rejected the API key (401). Check it in Nova's settings."
            402 -> "Your OpenRouter account is out of credits (402)."
            404 -> "Model not found (404). Check the model ID. $msg"
            429 -> "Too many requests (429). Wait a moment and try again."
            else -> "OpenRouter error $code: $msg"
        }
    }

    companion object {
        const val ENDPOINT = "https://openrouter.ai/api/v1/chat/completions"

        fun textPart(text: String): JSONObject =
            JSONObject().put("type", "text").put("text", text)

        fun imagePart(base64Jpeg: String): JSONObject =
            JSONObject().put("type", "image_url").put(
                "image_url", JSONObject().put("url", "data:image/jpeg;base64,$base64Jpeg")
            )

        fun msg(role: String, content: Any): JSONObject =
            JSONObject().put("role", role).put("content", content)
    }
}
