package com.nova.assistant

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo

/** One thing on screen the AI can refer to by number. */
data class ScreenElement(
    val id: Int,
    val node: AccessibilityNodeInfo,
    val bounds: Rect,
    val editable: Boolean,
    val scrollable: Boolean,
)

data class ScreenSnapshot(
    val elements: List<ScreenElement>,
    val description: String,
    val foregroundPackage: String,
)

/** Turns the accessibility tree of every visible window into a compact numbered list. */
class ScreenReader(private val service: AccessibilityService) {

    /**
     * @param scale multiply screen pixels by this so coordinates match the screenshot the model sees.
     */
    fun snapshot(scale: Float, maxElements: Int = 160): ScreenSnapshot {
        val ownPackage = service.packageName
        val elements = ArrayList<ScreenElement>()
        val sb = StringBuilder()
        var foreground = ""

        val roots = ArrayList<Pair<String, AccessibilityNodeInfo>>()
        try {
            for (w in service.windows) {
                val root = w.root ?: continue
                val pkg = root.packageName?.toString() ?: ""
                if (pkg == ownPackage) continue
                val kind = when (w.type) {
                    AccessibilityWindowInfo.TYPE_APPLICATION -> "app"
                    AccessibilityWindowInfo.TYPE_INPUT_METHOD -> "keyboard"
                    AccessibilityWindowInfo.TYPE_SYSTEM -> "system"
                    else -> "window"
                }
                if (kind == "app" && foreground.isEmpty() && w.isActive) foreground = pkg
                roots.add("$kind:$pkg" to root)
            }
        } catch (_: Exception) {}

        if (roots.isEmpty()) {
            service.rootInActiveWindow?.let { r ->
                val pkg = r.packageName?.toString() ?: ""
                if (pkg != ownPackage) roots.add("app:$pkg" to r)
            }
        }
        if (foreground.isEmpty()) {
            foreground = roots.firstOrNull { it.first.startsWith("app:") }?.first?.removePrefix("app:") ?: ""
        }

        for ((label, root) in roots) {
            if (elements.size >= maxElements) break
            sb.append("== ").append(label).append(" ==\n")
            walk(root, elements, sb, scale, maxElements, 0)
        }
        if (elements.size >= maxElements) sb.append("(more elements not shown)\n")
        if (elements.isEmpty()) sb.append("(no readable elements — rely on the screenshot)\n")

        return ScreenSnapshot(elements, sb.toString(), foreground)
    }

    private fun walk(
        node: AccessibilityNodeInfo,
        out: MutableList<ScreenElement>,
        sb: StringBuilder,
        scale: Float,
        max: Int,
        depth: Int,
    ) {
        if (out.size >= max || depth > 40) return
        if (!node.isVisibleToUser) return

        val text = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        val hint = node.hintText?.toString()?.trim().orEmpty()
        val clickable = node.isClickable || node.isLongClickable
        val editable = node.isEditable
        val scrollable = node.isScrollable
        val checkable = node.isCheckable

        val interesting = text.isNotEmpty() || desc.isNotEmpty() || clickable || editable || scrollable || checkable
        if (interesting) {
            val r = Rect()
            node.getBoundsInScreen(r)
            if (r.width() > 0 && r.height() > 0) {
                val id = out.size + 1
                out.add(ScreenElement(id, node, r, editable, scrollable))
                sb.append('[').append(id).append("] ")
                sb.append(shortClass(node.className?.toString()))
                if (text.isNotEmpty()) sb.append(" \"").append(clip(text)).append('"')
                if (desc.isNotEmpty() && desc != text) sb.append(" desc=\"").append(clip(desc)).append('"')
                if (editable && hint.isNotEmpty() && hint != text) sb.append(" hint=\"").append(clip(hint)).append('"')
                val cx = (r.centerX() * scale).toInt()
                val cy = (r.centerY() * scale).toInt()
                sb.append(" @(").append(cx).append(',').append(cy).append(')')
                if (clickable) sb.append(" tap")
                if (editable) sb.append(" EDIT")
                if (scrollable) sb.append(" SCROLL")
                if (checkable) sb.append(if (node.isChecked) " [on]" else " [off]")
                if (node.isFocused) sb.append(" focused")
                if (!node.isEnabled) sb.append(" disabled")
                sb.append('\n')
            }
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            walk(child, out, sb, scale, max, depth + 1)
            if (out.size >= max) return
        }
    }

    private fun shortClass(cls: String?): String {
        if (cls.isNullOrEmpty()) return "View"
        return cls.substringAfterLast('.')
    }

    private fun clip(s: String, max: Int = 120): String {
        val one = s.replace('\n', ' ')
        return if (one.length <= max) one else one.take(max) + "…"
    }
}
