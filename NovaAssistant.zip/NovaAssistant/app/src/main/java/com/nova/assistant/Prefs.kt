package com.nova.assistant

import android.content.Context

/** Simple local settings storage (kept only on this phone). */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("nova_settings", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("api_key", "") ?: ""
        set(v) = sp.edit().putString("api_key", v.trim()).apply()

    var model: String
        get() = sp.getString("model", "") ?: ""
        set(v) = sp.edit().putString("model", v.trim()).apply()

    /** Send screenshots to the model (needs a vision model). */
    var useVision: Boolean
        get() = sp.getBoolean("use_vision", true)
        set(v) = sp.edit().putBoolean("use_vision", v).apply()

    /** Read replies out loud after you talk to it with the mic. */
    var speakReplies: Boolean
        get() = sp.getBoolean("speak_replies", true)
        set(v) = sp.edit().putBoolean("speak_replies", v).apply()

    /** Max device steps per task, so a confused model can't loop forever. */
    var maxSteps: Int
        get() = sp.getInt("max_steps", 30)
        set(v) = sp.edit().putInt("max_steps", v.coerceIn(5, 100)).apply()

    val isConfigured: Boolean get() = apiKey.isNotBlank() && model.isNotBlank()
}
