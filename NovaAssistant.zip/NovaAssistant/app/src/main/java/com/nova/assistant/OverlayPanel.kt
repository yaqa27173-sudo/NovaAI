package com.nova.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

/**
 * The floating assistant UI drawn over any app:
 *  - expanded: a chat sheet at the bottom (type or talk)
 *  - mini: a small status pill at the top while Nova is controlling the phone
 */
@SuppressLint("SetTextI18n")
class OverlayPanel(private val service: AgentService) : Agent.Listener {

    private val ctx: Context = service
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val prefs = Prefs(ctx)
    val agent = Agent(service, this)

    private var expandedRoot: FrameLayout? = null
    private var miniRoot: LinearLayout? = null
    private lateinit var messages: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var statusView: TextView
    private lateinit var sendBtn: TextView
    private lateinit var micBtn: TextView
    private lateinit var modelView: TextView
    private lateinit var spacer: View
    private var miniStatus: TextView? = null

    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var lastInputWasVoice = false
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    val isShowing: Boolean get() = expandedRoot?.isAttachedToWindow == true || miniRoot?.isAttachedToWindow == true

    // ------------------------------------------------------------- colors

    private val bgCard = Color.parseColor("#16161D")
    private val bgBubbleAi = Color.parseColor("#24242F")
    private val accent = Color.parseColor("#7C5CFF")
    private val textMain = Color.parseColor("#F2F2F7")
    private val textDim = Color.parseColor("#9A9AAE")
    private val danger = Color.parseColor("#FF5C6C")

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), ctx.resources.displayMetrics).toInt()

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radiusDp).toFloat() }

    // ------------------------------------------------------------- show / hide

    fun show() {
        removeMini()
        if (expandedRoot == null) buildExpanded()
        val root = expandedRoot!!
        if (!root.isAttachedToWindow) {
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.BOTTOM
                softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            }
            try { wm.addView(root, lp) } catch (e: Exception) {
                Toast.makeText(ctx, "Nova can't show its panel: ${e.message}", Toast.LENGTH_LONG).show()
                return
            }
        }
        root.visibility = View.VISIBLE
        modelView.text = prefs.model.ifEmpty { "no model set" }
        if (messages.childCount == 0) {
            addAiBubble(
                if (prefs.isConfigured) "Hi, I'm Nova. Ask me anything, or tell me what to do on your phone."
                else "Hi! Open the Nova app first (⚙) and enter your OpenRouter API key and model ID."
            )
        }
        updateRunningUi(agent.isRunning)
    }

    fun hide() {
        if (agent.isRunning) agent.stop()
        stopListening()
        hideKeyboard()
        removeExpanded()
        removeMini()
    }

    fun destroy() {
        hide()
        recognizer?.destroy(); recognizer = null
        tts?.shutdown(); tts = null
    }

    private fun removeExpanded() {
        expandedRoot?.let { if (it.isAttachedToWindow) try { wm.removeView(it) } catch (_: Exception) {} }
    }

    private fun removeMini() {
        miniRoot?.let { if (it.isAttachedToWindow) try { wm.removeView(it) } catch (_: Exception) {} }
        miniRoot = null
        miniStatus = null
    }

    private fun showMini() {
        hideKeyboard()
        removeExpanded()
        if (miniRoot != null) return
        val pill = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Color.parseColor("#EE16161D"), 22)
            setPadding(dp(14), dp(8), dp(8), dp(8))
            elevation = dp(6).toFloat()
        }
        val dot = View(ctx).apply { background = rounded(accent, 6) }
        pill.addView(dot, LinearLayout.LayoutParams(dp(10), dp(10)).apply { rightMargin = dp(10) })
        val status = TextView(ctx).apply {
            setTextColor(textMain); textSize = 13f; maxLines = 2
            maxWidth = (ctx.resources.displayMetrics.widthPixels * 0.62).toInt()
            text = "Working…"
        }
        pill.addView(status)
        val stop = TextView(ctx).apply {
            text = "Stop"; setTextColor(Color.WHITE); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            background = rounded(danger, 16)
            setPadding(dp(14), dp(6), dp(14), dp(6))
            setOnClickListener { agent.stop(); status.text = "Stopping…" }
        }
        pill.addView(stop, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(10) })

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(36)
        }
        try {
            wm.addView(pill, lp)
            miniRoot = pill
            miniStatus = status
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------------- build UI

    private fun buildExpanded() {
        val root = object : FrameLayout(ctx) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                    hide(); return true
                }
                return super.dispatchKeyEvent(event)
            }
        }

        val column = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        root.addView(column, FrameLayout.LayoutParams(-1, -1))

        spacer = View(ctx).apply { setOnClickListener { hide() } }
        root.setBackgroundColor(Color.parseColor("#40000000")) // light dim over the app behind
        column.addView(spacer, LinearLayout.LayoutParams(-1, 0, 0.38f))

        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(bgCard)
                val r = dp(26).toFloat()
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            }
            setPadding(dp(14), dp(10), dp(14), dp(12))
            isClickable = true // don't let taps fall through to the spacer
        }
        column.addView(card, LinearLayout.LayoutParams(-1, 0, 0.62f))

        // grab handle
        val handle = View(ctx).apply { background = rounded(Color.parseColor("#3A3A48"), 3) }
        card.addView(handle, LinearLayout.LayoutParams(dp(40), dp(5)).apply {
            gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(8)
        })

        // header
        val header = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titleCol = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        titleCol.addView(TextView(ctx).apply {
            text = "✦ Nova"; setTextColor(textMain); textSize = 18f; typeface = Typeface.DEFAULT_BOLD
        })
        modelView = TextView(ctx).apply { setTextColor(textDim); textSize = 11f; maxLines = 1 }
        titleCol.addView(modelView)
        header.addView(titleCol, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(chip("New") { newChat() })
        header.addView(chip("⚙") { openSettings() })
        header.addView(chip("✕") { hide() })
        card.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

        // messages
        scroll = ScrollView(ctx).apply { isFillViewport = true; isVerticalScrollBarEnabled = false }
        messages = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, dp(4)) }
        scroll.addView(messages, ViewGroup.LayoutParams(-1, -2))
        card.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        // status line
        statusView = TextView(ctx).apply {
            setTextColor(textDim); textSize = 12f; maxLines = 2; visibility = View.GONE
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        card.addView(statusView)

        // input row
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM
            background = rounded(Color.parseColor("#20202A"), 24)
            setPadding(dp(14), dp(4), dp(6), dp(4))
        }
        input = EditText(ctx).apply {
            hint = "Ask or tell Nova to do something…"
            setHintTextColor(textDim); setTextColor(textMain); textSize = 15f
            background = null
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            maxLines = 5
            setPadding(0, dp(10), 0, dp(10))
        }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        micBtn = roundButton("🎤", Color.parseColor("#2E2E3A")) { toggleListening() }
        row.addView(micBtn, LinearLayout.LayoutParams(dp(42), dp(42)).apply { leftMargin = dp(4); bottomMargin = dp(2) })
        sendBtn = roundButton("➤", accent) { onSendPressed() }
        row.addView(sendBtn, LinearLayout.LayoutParams(dp(42), dp(42)).apply { leftMargin = dp(6); bottomMargin = dp(2) })
        card.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        // keep the input above the keyboard and nav bar
        root.setOnApplyWindowInsetsListener { v, insets ->
            val ime = insets.getInsets(WindowInsets.Type.ime()).bottom
            val nav = insets.getInsets(WindowInsets.Type.navigationBars()).bottom
            val top = insets.getInsets(WindowInsets.Type.statusBars()).top
            v.setPadding(0, top, 0, maxOf(ime, nav))
            val lp = spacer.layoutParams as LinearLayout.LayoutParams
            val w = if (ime > 0) 0.06f else 0.38f
            if (lp.weight != w) { lp.weight = w; spacer.layoutParams = lp }
            if (ime > 0) scrollToBottom()
            insets
        }
        expandedRoot = root
    }

    private fun chip(label: String, onClick: () -> Unit): TextView = TextView(ctx).apply {
        text = label; setTextColor(textMain); textSize = 13f; gravity = Gravity.CENTER
        background = rounded(Color.parseColor("#262632"), 16)
        setPadding(dp(12), dp(6), dp(12), dp(6))
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(6) }
        setOnClickListener { onClick() }
    }

    private fun roundButton(label: String, color: Int, onClick: () -> Unit): TextView = TextView(ctx).apply {
        text = label; setTextColor(Color.WHITE); textSize = 17f; gravity = Gravity.CENTER
        background = rounded(color, 21)
        setOnClickListener { onClick() }
    }

    private fun addBubble(text: String, fromUser: Boolean, color: Int = if (fromUser) accent else bgBubbleAi) {
        val tv = TextView(ctx).apply {
            this.text = text
            setTextColor(textMain); textSize = 15f
            setLineSpacing(0f, 1.15f)
            background = rounded(color, 18)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            maxWidth = (ctx.resources.displayMetrics.widthPixels * 0.80).toInt()
            setOnLongClickListener {
                service.copyToClipboard(text)
                Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
                true
            }
        }
        val lp = LinearLayout.LayoutParams(-2, -2).apply {
            gravity = if (fromUser) Gravity.END else Gravity.START
            topMargin = dp(6)
        }
        messages.addView(tv, lp)
        scrollToBottom()
    }

    private fun addAiBubble(text: String) = addBubble(text, false)

    private fun scrollToBottom() {
        if (::scroll.isInitialized) scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    // ------------------------------------------------------------- actions

    private fun onSendPressed() {
        if (agent.isRunning) { agent.stop(); return }
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        send(text, voice = false)
    }

    private fun send(text: String, voice: Boolean) {
        lastInputWasVoice = voice
        tts?.stop()
        addBubble(text, true)
        hideKeyboard()
        agent.submit(text)
    }

    private fun newChat() {
        if (agent.isRunning) agent.stop()
        agent.clearConversation()
        messages.removeAllViews()
        addAiBubble("New chat. What can I do for you?")
    }

    private fun openSettings() {
        hide()
        val i = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (_: Exception) {}
    }

    private fun hideKeyboard() {
        if (!::input.isInitialized) return
        val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(input.windowToken, 0)
        input.clearFocus()
    }

    private fun updateRunningUi(running: Boolean) {
        if (!::sendBtn.isInitialized) return
        sendBtn.text = if (running) "■" else "➤"
        sendBtn.background = rounded(if (running) danger else accent, 21)
        if (!running) statusView.visibility = View.GONE
    }

    // ------------------------------------------------------------- voice in

    private fun toggleListening() {
        if (listening) { stopListening(); return }
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            addAiBubble("I need microphone permission. Open the Nova app and tap \"Allow microphone\".")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            addAiBubble("Speech recognition isn't available. Install or enable the Google app / Speech Services by Google.")
            return
        }
        tts?.stop()
        val r = recognizer ?: SpeechRecognizer.createSpeechRecognizer(ctx).also { recognizer = it }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { setStatus("Listening… speak now") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { setStatus("Got it…") }
            override fun onError(error: Int) {
                listening = false; micUi()
                val msg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Didn't catch that. Tap the mic and try again."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is missing."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Voice needs an internet connection."
                    else -> "Voice error ($error)."
                }
                setStatus(msg)
            }
            override fun onResults(results: Bundle?) {
                listening = false; micUi()
                statusView.visibility = View.GONE
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim()
                if (!text.isNullOrEmpty()) { input.setText(""); send(text, voice = true) }
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrEmpty()) input.setText(t)
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        try {
            r.startListening(intent)
            listening = true; micUi()
        } catch (e: Exception) {
            setStatus("Couldn't start the mic: ${e.message}")
        }
    }

    private fun stopListening() {
        if (listening) try { recognizer?.stopListening() } catch (_: Exception) {}
        listening = false
        micUi()
    }

    private fun micUi() {
        if (!::micBtn.isInitialized) return
        micBtn.background = rounded(if (listening) danger else Color.parseColor("#2E2E3A"), 21)
    }

    // ------------------------------------------------------------- voice out

    private fun speak(text: String) {
        if (!prefs.speakReplies || !lastInputWasVoice) return
        val clean = text.replace(Regex("```[\\s\\S]*?```"), " (code shown on screen) ")
            .replace(Regex("[*_#`>]"), "").take(1200)
        val t = tts
        if (t == null) {
            tts = TextToSpeech(ctx) { status ->
                ttsReady = status == TextToSpeech.SUCCESS
                if (ttsReady) {
                    tts?.language = Locale.getDefault()
                    tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "nova")
                }
            }
        } else if (ttsReady) {
            t.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "nova")
        }
    }

    // ------------------------------------------------------------- Agent.Listener (any thread)

    private fun setStatus(text: String) {
        if (!::statusView.isInitialized) return
        statusView.text = text
        statusView.visibility = View.VISIBLE
    }

    override fun onRunningChanged(running: Boolean) {
        main.post {
            updateRunningUi(running)
            if (!running && miniRoot != null) show() // finished/stopped while minimized
        }
    }

    override fun onStatus(text: String) {
        main.post {
            setStatus(text)
            miniStatus?.text = text
        }
    }

    override fun onReply(text: String, question: Boolean) {
        main.post {
            if (miniRoot != null || expandedRoot?.isAttachedToWindow != true) show()
            statusView.visibility = View.GONE
            addAiBubble(text)
            speak(text)
        }
    }

    override fun onError(text: String) {
        main.post {
            if (miniRoot != null || expandedRoot?.isAttachedToWindow != true) show()
            addBubble("⚠ $text", false, Color.parseColor("#3A1E26"))
        }
    }

    override fun setHiddenForCapture(hidden: Boolean) {
        val v = if (hidden) View.INVISIBLE else View.VISIBLE
        expandedRoot?.visibility = v
        miniRoot?.visibility = v
    }

    override fun onDeviceControlStarted() {
        showMini()
    }
}
