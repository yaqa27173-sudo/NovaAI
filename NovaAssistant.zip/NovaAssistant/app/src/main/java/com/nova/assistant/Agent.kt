package com.nova.assistant

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.os.Build
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/**
 * The brain loop: look at the screen -> ask the model what to do -> do it -> repeat,
 * until the model replies to the user or asks a question.
 */
class Agent(private val service: AgentService, private val listener: Listener) {

    interface Listener {
        fun onRunningChanged(running: Boolean)
        fun onStatus(text: String)
        /** A message for the user. [question] = the AI is waiting for an answer. */
        fun onReply(text: String, question: Boolean)
        fun onError(text: String)
        /** Hide/show the floating UI so it isn't in the screenshot. Called on the UI thread. */
        fun setHiddenForCapture(hidden: Boolean)
        /** The agent is about to touch other apps: shrink the panel out of the way. */
        fun onDeviceControlStarted()
    }

    private val history = ArrayList<JSONObject>()
    @Volatile private var running = false
    @Volatile private var stopRequested = false
    private var client: OpenRouterClient? = null
    private var worker: Thread? = null
    private var lastSnapshot: ScreenSnapshot? = null
    private var lastScale = 1f

    val isRunning: Boolean get() = running

    fun clearConversation() {
        if (!running) history.clear()
    }

    fun stop() {
        stopRequested = true
        client?.cancel()
        worker?.interrupt()
    }

    fun submit(userText: String) {
        if (running) return
        val prefs = Prefs(service)
        if (!prefs.isConfigured) {
            listener.onError("Open the Nova app and enter your OpenRouter API key and model ID first.")
            return
        }
        running = true
        stopRequested = false
        listener.onRunningChanged(true)
        val c = OpenRouterClient(prefs.apiKey, prefs.model)
        client = c
        worker = Thread({
            try {
                runTask(userText, c, prefs)
            } catch (_: InterruptedException) {
                listener.onStatus("Stopped.")
            } catch (e: Exception) {
                if (stopRequested) listener.onStatus("Stopped.")
                else listener.onError(e.message ?: e.toString())
            } finally {
                running = false
                client = null
                listener.onRunningChanged(false)
            }
        }, "nova-agent").also { it.start() }
    }

    // ------------------------------------------------------------------ loop

    private fun runTask(userText: String, c: OpenRouterClient, prefs: Prefs) {
        var resultOfLast: String? = null
        var controlledDevice = false
        val maxSteps = prefs.maxSteps

        for (step in 1..maxSteps) {
            if (stopRequested) { listener.onStatus("Stopped."); return }

            listener.onStatus(if (step == 1) "Looking at the screen…" else "Step $step: looking…")
            val obs = observe(prefs.useVision)

            val header = StringBuilder()
            if (step == 1) header.append("User: ").append(userText).append("\n\n")
            else header.append("Result of your last action: ").append(resultOfLast).append("\n\n")
            header.append("[Step ").append(step).append(" of max ").append(maxSteps).append("]\n")
            header.append("Foreground app: ").append(obs.snapshot.foregroundPackage.ifEmpty { "unknown" }).append('\n')
            header.append("Screen coordinate space: ").append(obs.width).append('x').append(obs.height)
            header.append(if (obs.imageBase64 != null) " (same as the attached screenshot)\n" else " (no screenshot this time)\n")

            val fullText = header.toString() + "UI elements:\n" + obs.snapshot.description
            val content: Any = if (obs.imageBase64 != null) {
                JSONArray().put(OpenRouterClient.textPart(fullText)).put(OpenRouterClient.imagePart(obs.imageBase64))
            } else fullText
            history.add(OpenRouterClient.msg("user", content))

            listener.onStatus(if (step == 1) "Thinking…" else "Step $step: thinking…")
            val raw = c.chat(buildMessages())
            if (stopRequested) return

            // Shrink the old observation so history stays small and cheap.
            history[history.size - 1] = OpenRouterClient.msg(
                "user", header.toString() + "(screen details from this step omitted)"
            )
            history.add(OpenRouterClient.msg("assistant", raw))
            trimHistory()

            val action = parseAction(raw)
            if (action == null) {
                // The model just talked instead of returning JSON — treat it as a reply.
                listener.onReply(raw.trim().ifEmpty { "(empty reply)" }, false)
                return
            }
            val type = action.optString("action").lowercase(Locale.US)
            val thought = action.optString("thought")

            when (type) {
                "reply", "answer", "done", "finish" -> {
                    listener.onReply(action.optString("text", thought).ifEmpty { "Done." }, false)
                    return
                }
                "ask" -> {
                    listener.onReply(action.optString("text", "Can you tell me more?"), true)
                    return
                }
            }

            if (!controlledDevice) {
                controlledDevice = true
                service.onMainSync { listener.onDeviceControlStarted() }
            }
            listener.onStatus(describe(type, action, thought))
            resultOfLast = try {
                execute(type, action)
            } catch (e: InterruptedException) {
                throw e
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
            Thread.sleep(if (type == "wait") 0 else 900) // let the screen settle
        }
        listener.onReply("I stopped after $maxSteps steps without finishing. Tell me how to continue, or raise the step limit in settings.", false)
    }

    private fun buildMessages(): JSONArray {
        val arr = JSONArray()
        arr.put(OpenRouterClient.msg("system", systemPrompt()))
        for (m in history) arr.put(m)
        return arr
    }

    private fun trimHistory() {
        while (history.size > 48) history.removeAt(0)
        while (history.isNotEmpty() && history[0].optString("role") != "user") history.removeAt(0)
    }

    // ------------------------------------------------------------------ seeing

    private class Observation(val snapshot: ScreenSnapshot, val imageBase64: String?, val width: Int, val height: Int)

    private fun observe(useVision: Boolean): Observation {
        val screen = service.screenSize()
        var scale = 1f
        var image: String? = null
        var w = screen.width()
        var h = screen.height()

        if (useVision) {
            service.onMainSync { listener.setHiddenForCapture(true) }
            Thread.sleep(160)
            val bmp = service.takeScreenshotBlocking()
            service.onMainSync { listener.setHiddenForCapture(false) }
            if (bmp != null) {
                val targetW = 720
                val s = if (bmp.width > targetW) targetW.toFloat() / bmp.width else 1f
                val scaled = if (s < 1f)
                    Bitmap.createScaledBitmap(bmp, (bmp.width * s).roundToInt(), (bmp.height * s).roundToInt(), true)
                else bmp
                val out = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, 70, out)
                image = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                // Map screen pixels -> screenshot pixels.
                scale = scaled.width.toFloat() / screen.width()
                w = scaled.width
                h = scaled.height
                if (scaled !== bmp) scaled.recycle()
                bmp.recycle()
            }
        }
        val snap = ScreenReader(service).snapshot(scale)
        lastSnapshot = snap
        lastScale = scale
        return Observation(snap, image, w, h)
    }

    // ------------------------------------------------------------------ doing

    private fun element(a: JSONObject): ScreenElement? {
        if (!a.has("id")) return null
        val id = a.optInt("id", -1)
        return lastSnapshot?.elements?.firstOrNull { it.id == id }
    }

    private fun px(a: JSONObject, key: String): Float = (a.optDouble(key, 0.0) / lastScale).toFloat()

    private fun execute(type: String, a: JSONObject): String {
        val el = element(a)
        return when (type) {
            "tap", "click" -> when {
                el != null -> if (service.clickNode(el.node)) "Tapped [${el.id}]." else "Tap on [${el.id}] failed."
                a.has("x") -> if (service.tap(px(a, "x"), px(a, "y"))) "Tapped (${a.opt("x")},${a.opt("y")})." else "Tap failed."
                else -> "Error: tap needs an id or x,y."
            }
            "long_press" -> when {
                el != null -> if (service.longClickNode(el.node)) "Long-pressed [${el.id}]." else "Long-press failed."
                a.has("x") -> if (service.longPress(px(a, "x"), px(a, "y"))) "Long-pressed." else "Long-press failed."
                else -> "Error: long_press needs an id or x,y."
            }
            "type" -> {
                val text = a.optString("text")
                val ok = service.setText(el?.node, text)
                var r = if (ok) "Typed text." else "Typing failed — tap the field first, or try paste."
                if (ok && a.optBoolean("enter", false)) {
                    Thread.sleep(300)
                    r += if (service.pressEnter(null)) " Pressed enter." else " Enter failed (tap the send/search button instead)."
                }
                r
            }
            "paste" -> {
                val ok = service.paste(el?.node, a.optString("text"))
                if (ok) "Pasted text." else "Paste failed — tap the field first, then try again."
            }
            "enter" -> if (service.pressEnter(el?.node)) "Pressed enter." else "Enter failed."
            "copy" -> { service.copyToClipboard(a.optString("text")); "Copied to clipboard." }
            "scroll" -> {
                val dir = a.optString("direction", "down").lowercase(Locale.US)
                if (service.scroll(dir, el?.node)) "Scrolled $dir." else "Scroll failed."
            }
            "swipe" -> if (service.swipe(px(a, "x1"), px(a, "y1"), px(a, "x2"), px(a, "y2"),
                    a.optLong("ms", 400))) "Swiped." else "Swipe failed."
            "back" -> ok(service.global(AccessibilityService.GLOBAL_ACTION_BACK), "Pressed back.")
            "home" -> ok(service.global(AccessibilityService.GLOBAL_ACTION_HOME), "Went home.")
            "recents" -> ok(service.global(AccessibilityService.GLOBAL_ACTION_RECENTS), "Opened recent apps.")
            "notifications" -> ok(service.global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS), "Opened notifications.")
            "quick_settings" -> ok(service.global(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS), "Opened quick settings.")
            "open_app" -> service.openApp(a.optString("name"))
            "open_url" -> service.openUrl(a.optString("url"))
            "wait" -> {
                val secs = a.optDouble("seconds", 2.0).coerceIn(0.5, 10.0)
                Thread.sleep((secs * 1000).toLong())
                "Waited ${secs}s."
            }
            else -> "Error: unknown action \"$type\". Use one of the listed actions."
        }
    }

    private fun ok(success: Boolean, msg: String) = if (success) msg else "Failed: $msg"

    private fun describe(type: String, a: JSONObject, thought: String): String {
        val what = when (type) {
            "tap", "click" -> "Tapping"
            "long_press" -> "Long-pressing"
            "type" -> "Typing"
            "paste" -> "Pasting text"
            "scroll" -> "Scrolling ${a.optString("direction", "down")}"
            "swipe" -> "Swiping"
            "back" -> "Going back"
            "home" -> "Going home"
            "open_app" -> "Opening ${a.optString("name")}"
            "open_url" -> "Opening ${a.optString("url")}"
            "wait" -> "Waiting"
            else -> type.replaceFirstChar { it.uppercase() }
        }
        return if (thought.isNotBlank()) "$what — $thought" else what
    }

    // ------------------------------------------------------------------ parsing

    private fun parseAction(raw: String): JSONObject? {
        var s = raw.trim()
        if (s.startsWith("```")) {
            s = s.removePrefix("```json").removePrefix("```JSON").removePrefix("```")
            val end = s.lastIndexOf("```")
            if (end >= 0) s = s.substring(0, end)
        }
        val start = s.indexOf('{')
        if (start < 0) return null
        // Find the matching closing brace for the first object.
        var depth = 0
        var inStr = false
        var esc = false
        for (i in start until s.length) {
            val ch = s[i]
            if (inStr) {
                if (esc) esc = false
                else if (ch == '\\') esc = true
                else if (ch == '"') inStr = false
                continue
            }
            when (ch) {
                '"' -> inStr = true
                '{' -> depth++
                '}' -> {
                    depth--
                    if (depth == 0) {
                        return try {
                            val o = JSONObject(s.substring(start, i + 1))
                            if (o.has("action")) o else null
                        } catch (_: Exception) { null }
                    }
                }
            }
        }
        return null
    }

    // ------------------------------------------------------------------ prompt

    private fun systemPrompt(): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.US).format(Date())
        return """
You are Nova, a helpful AI assistant that lives on the user's Android phone (${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}). Current time: $now.
You can chat, answer questions, explain things, write and improve text, write code — AND you can see and control the phone like a person would.

Every turn you receive the latest screen: a numbered list of UI elements like [12] Button "Send" @(x,y) tap, and usually a screenshot.
The user cannot see this list; they only see your replies.

Respond with exactly ONE JSON object and nothing else:
{"thought": "very short plan for this step", "action": "<name>", ...parameters}

Actions:
- {"action":"reply","text":"..."}  Talk to the user / give your final answer. This ends your turn.
- {"action":"ask","text":"..."}  Ask the user a question you need answered. Ends your turn.
- {"action":"tap","id":12}  or  {"action":"tap","x":360,"y":800}
- {"action":"long_press","id":12}
- {"action":"type","id":5,"text":"hello","enter":false}  Replace the text in an input field (enter:true presses enter/search after).
- {"action":"paste","id":5,"text":"..."}  Best for long text and code (uses clipboard + paste).
- {"action":"enter"}  Press enter / search on the keyboard.
- {"action":"copy","text":"..."}  Copy text to the clipboard.
- {"action":"scroll","direction":"down|up|left|right","id":7}  (id optional)
- {"action":"swipe","x1":360,"y1":1200,"x2":360,"y2":400}
- {"action":"back"} {"action":"home"} {"action":"recents"} {"action":"notifications"} {"action":"quick_settings"}
- {"action":"open_app","name":"Gmail"}
- {"action":"open_url","url":"https://www.google.com/search?q=..."}
- {"action":"wait","seconds":2}

How to work:
- If the request is a question, conversation, writing help or code you can just give, reply right away. Don't touch the phone unless needed.
- If the user refers to "this", "the text", "this page", "this email" etc., they mean what's on the screen: read it from the UI elements/screenshot.
- For phone tasks, do one action per turn, then check the new screen to confirm it worked. If something didn't work, try another way (different element, coordinates, scrolling, back).
- Prefer tapping by id. Coordinates are in the given screen coordinate space.
- To search the web, open_url a Google search URL. To find things in an app, use its search.
- To write code on a website or editor, open it, tap the editor, then use paste with the code.
- When the task is complete, reply with a short summary of what you did (and any answer they asked for).
- Before anything irreversible or sensitive — sending a message or email, posting, buying, paying, deleting, changing security settings — use "ask" to confirm, unless the user already clearly told you to do exactly that.
- Never type passwords or payment details unless the user gave them for this exact task.
- Answer in the same language the user writes in. Keep replies concise and friendly.
""".trim()
    }
}
